module.exports = {
    name: "test",
    description: "this is just test",
    prefix: false,
    async execute() {
        
    }
}